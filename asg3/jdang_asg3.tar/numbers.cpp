#include <iostream>

int main() {
  int i = 0;
  while (i != -1) {
    std::cin >> i;
    std::cout << i << std::endl;
  }
  return 0;
}
